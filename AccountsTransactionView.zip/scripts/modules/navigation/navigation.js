(function(){
	'use strict';

	var navigation = angular.module('navigation',[])
		.controller('navigation',function($scope){
		      $scope.menu  = [{name:'home',link:'index.home'}]

		})

})()