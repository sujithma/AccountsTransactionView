(function(){
	'use strict';
	var rolesService	=	angular.module('rolesService',[])
		.service('rolesService',function(){
			var rolesData	=	{};
			this.setData = function(data) {
			      rolesData =  data;
			    };
			this.getData = function(){
				return rolesData;
			}    
			this.pushData = function(data){
				rolesData.push(data);
				console.log(rolesData.length);
			}
			this.spliceData = function(index,count){
				console.log(index);
				console.log(rolesData.indexOf(index));
				//rolesData.splice(index,count);
			}
			// this.findIndex = function(arr,){

			// }
			
			return this;
		});
})();