(function(){
	'use strict';
	var role = angular.module('roles',['rolesController'])
	.config(function($stateProvider,$urlRouterProvider){
		$urlRouterProvider.otherwise('index.roles');
		$stateProvider
			.state('index.roles',{
				url : '/roles',
				cache:false,
				controller : 'rolesController',
				templateUrl : 'views/roles/roles.html'

			})

			.state('index.roles.add',{
				url : '/add',
				controller : 'rolesController',
				templateUrl : 'views/roles/roles_add.html'

			})
			// state('index.users.edit',{
	  //         		url:'/users/:id',
	  //         		controller:'rolesControllerEdit',
	  //               template: '<p>Edit id is {{id}}</p>'
	  //         })
	})
})();