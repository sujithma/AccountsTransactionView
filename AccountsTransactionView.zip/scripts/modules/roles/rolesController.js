(function(){
	'use strict';
	var rolesController	=	angular.module('rolesController',['rolesFactory','rolesService'])
		.controller('rolesController',function(rolesFact,$scope,$state,Notification,rolesService){
			$scope.data = rolesService.getData()||[];
			rolesFact.Roles()
		    	.then(function(e){
		    		rolesService.setData(e.data);
		    		$scope.data = rolesService.getData();
		    	})
		    $scope.closebox	=	function(){
		    	$state.go('index.roles');
		    };
		    $scope.save	=	function(){
		    	var $role =	{'role_name': $scope.role_name};
		    	rolesFact.add($role)
		    		.then(function(re){
		    			rolesService.pushData($role);
		    			Notification.success('Success notification');
		    			$state.go('index.roles');
		    		},function(){
		    			Notification.warning('Success notification');
		    		})	
		    };
		   $scope.delete = function($id){
		   		var $id =	{'id': $id};
		   		 rolesService.spliceData($id,1);
				// rolesFact.delet($id)
			 //    	.then(function(e){
			 //    		  Notification.success('Success notification');
			 //    		  $scope.data.splice($id,1);
			 //    	},function(){
			 //    		    Notification.warning({message: 'Errorr', title: 'Error Occured'});
			 //    	})	
			};   

		});	 
		
})();