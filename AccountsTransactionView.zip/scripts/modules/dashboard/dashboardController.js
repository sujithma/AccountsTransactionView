(function(){
	'use strict';
	var dashboardController	=	angular.module('dashboardController',[])
		.controller('dashboardController',function($scope){


		});

})();