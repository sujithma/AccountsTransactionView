(function(){
	'use strict';

	var factories = angular.module('factories',[
		'userFactory',
		'loginFactory',
		'dashboardFactory',
		'rolesFactory',
		'categoriesFactory'
	]);	

})();